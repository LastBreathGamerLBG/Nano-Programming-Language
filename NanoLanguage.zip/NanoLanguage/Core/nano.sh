#!/bin/bash
python3 "core.py" "$1"