#!/bin/bash
python3 "yoyo.py" "$1" "$2"